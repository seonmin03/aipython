a="apple#banana#cherry#orange"
x=a.split("#")
print(x)