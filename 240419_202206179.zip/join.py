word={'python', 'java', 'ruby'}
sentence='->'.join(word)
print(sentence)