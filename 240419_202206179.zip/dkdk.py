citys=["Seoul", "New York", "London", "Shanghai", "Paris", "Tokyo"]
newlist=[city for city in citys if city.startswith('S')]
print(newlist)