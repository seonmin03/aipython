word=['Python', 'Java', 'JavaScript']
newlist=[(idx, name) for idx, name in enumerate(word, start=1)] #start=1 -> 1부터 실행
print(newlist)