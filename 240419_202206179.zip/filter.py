#lambda, filter 사용
def myFunc(x):
    if x>=18:
        return True
    else:
        return False  #사용자 정의 함수 이용해서 할 수도 있지만 lambda를 이용하는게 훨씬 간단함
ages = [5, 12, 17, 18, 24, 32]
newlist=list(filter(lambda x: x>=18, ages))
print(newlist)